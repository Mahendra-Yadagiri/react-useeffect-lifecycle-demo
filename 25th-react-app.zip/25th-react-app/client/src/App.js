import { useState } from 'react';
import './App.css';
import FCCounter from './components/FCCounter';
import CCCounter from './components/CCCounter';

function App() {
  let [show,setShow] = useState(false)
  return (
    <div className="App">
      <button onClick={()=>{
        if(show === true){
          setShow(false)
        }else{
          setShow(true)
        }

      }}>Enter-Score</button>
      <br></br>
      {show === true ? <FCCounter/>:null}
      {show === true ? <CCCounter/>:null}

     
      
    </div>
  );
}

export default App;

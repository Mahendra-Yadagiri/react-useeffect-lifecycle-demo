import React, { useEffect, useState } from 'react'

function FCCounter() {
    let [score,setScore] = useState(0);
    let [wickets,setWickets] = useState(0);
    useEffect(()=>{
        console.log("FCCounter - on Component loaded");
        return ()=>{
            console.log("FFCounter - on Component unloaded");
        }
    },[]);

    useEffect(()=>{
        console.log("FCCounter -  Score SV Changed")
    },[score]);

     useEffect(()=>{
        console.log("FCCounter -  wickets SV Changed")
    },[wickets]);

    useEffect(()=>{
        console.log("FCCounter -  wickets or score SV Changed")
    },[wickets,score]);

    useEffect(()=>{
        console.log("FCCounter -  any sv Changed")
    },[]);

  return (
    <div className='counter'>
        <h1>India</h1>
        <h2>Score:{score}/{wickets}</h2>
        <button onClick={()=>{
            setScore(score +1)
        }}>Increment Score</button>
        <button onClick={()=>{
            setScore(score -1)
        }}>Decrement Score</button>
         <br></br>

        <button onClick={()=>{
            setWickets(wickets +1)
        }}>Increment Wickets</button>
        <button onClick={()=>{
            setWickets(wickets -1)
        }}>Decrement Wickets</button>
      
    </div>
  )
}

export default FCCounter

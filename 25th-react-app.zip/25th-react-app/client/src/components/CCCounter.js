import React, { Component } from 'react'

class CCCounter extends Component {
    constructor(props) {
      super(props)
    
      this.state = {
         score:0,
         wickets:0
      }
    }
    componentDidMount(){
      console.log("CCCounter- onLoading")
    }
    componentWillUnmount = ()=>{
      console.log("CCCounter- unLoading")
    }
    shouldComponentUpdate(){
      console.log("CCCounter- should component update");
      return true

    }
    componentDidUpdate(){
      console.log("CCCounter- component update");
    }
    
  render() {
    console.log("CCCounter-render")
    return (
      <div className='counter'>
        <h1>West-Indies</h1>
         <h2>Score:{this.state.score}/{this.state.wickets}</h2>

        <button onClick={()=>{
            this.setState({score:this.state.score +1})
           
        }}>Increment Score</button>
        <button onClick={()=>{
             this.setState({score:this.state.score -1})
        }}>Decrement Score</button>
         <br></br>

        <button onClick={()=>{
             this.setState({wickets:this.state.wickets +1})
            
        }}>Increment Wickets</button>
        <button onClick={()=>{
            this.setState({wickets:this.state.wickets -1})
            
        }}>Decrement Wickets</button>
      
    </div>
    )
  }
}
export default CCCounter;
